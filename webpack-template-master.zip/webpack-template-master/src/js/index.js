// Main js file

// another js file (example)
import './common.js'